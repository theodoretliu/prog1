#!/usr/bin/env bash
java Driver $1 $2 $3 $4

